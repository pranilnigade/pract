jtag.exe -c tumpa -v -p 0 MOD25.bit

/*replace cnt3bit.bit file with 
your project_name.bit */