jtag.exe -c tumpa -v -p 0 LCD_FSM.bit

/*replace cnt3bit.bit file with 
your project_name.bit */