
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.NUMERIC_STD.ALL;
 
ENTITY ALU_4_TVM IS
END ALU_4_TVM;
 
ARCHITECTURE behavior OF ALU_4_TVM IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT ALU_4
    PORT(
         A : IN  std_logic_vector(3 downto 0);
         B : IN  std_logic_vector(3 downto 0);
         F : IN  std_logic_vector(2 downto 0);
         Y : OUT  std_logic_vector(3 downto 0);
         C_B : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal A : std_logic_vector(3 downto 0) :=  "1001";
   signal B : std_logic_vector(3 downto 0) :=  "1011";
   signal F : std_logic_vector(2 downto 0) := (others => '1');

 	--Outputs
   signal Y : std_logic_vector(3 downto 0);
   signal C_B : std_logic;
   -- No clocks detected in port list. Replace <clock> below with 
   -- appropriate port name 
 
  
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: ALU_4 PORT MAP (
          A => A,
          B => B,
          F => F,
          Y => Y,
          C_B => C_B
        );

   -- Stimulus process
   stim_proc_F: process
   begin		
     F<=F+1;
	  WAIT FOR 100 NS;
   end process;

END;
