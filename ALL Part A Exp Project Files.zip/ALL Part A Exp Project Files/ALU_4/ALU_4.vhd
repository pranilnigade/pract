
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.NUMERIC_STD.ALL;


entity ALU_4 is
    Port ( A : in  STD_LOGIC_VECTOR (3 downto 0);
           B : in  STD_LOGIC_VECTOR (3 downto 0);
           F : in  STD_LOGIC_VECTOR (2 downto 0);
           Y : out  STD_LOGIC_VECTOR (3 downto 0);
           C_B : out  STD_LOGIC);
end ALU_4;

architecture ALU_4_ARCH of ALU_4 is


	SIGNAL RESULT: STD_LOGIC_VECTOR(4 DOWNTO 0):=(OTHERS=>'0');
	BEGIN
		PROCESS(A,B,F)
		BEGIN
			CASE F IS
			--6 LOGICAL OPERATIONS , F="000" TO F="101"
			
			WHEN "000" => RESULT<= '0' & (A AND B);
			WHEN "001" => RESULT<= '0' & (A NAND B);
			WHEN "010" => RESULT<= '0' & (A OR B);
			WHEN "011" => RESULT<= '0' & (A NOR B);
			WHEN "100" => RESULT<= '0' & (A XOR B);
			WHEN "101" => RESULT<= '0' & (A XNOR B);
			
			WHEN "110" => RESULT <=('0' & A)+('0' & B);
				WHEN OTHERS => 
					IF A < B THEN
						RESULT <= '0' &(NOT B);
						RESULT<=RESULT+1;
						RESULT<=(NOT RESULT) + 1;
						RESULT<= (NOT(('0' & A) + ('0' &(NOT B)) + 1))+1;
					ELSE
						RESULT <= ('0' & A ) - ('0' & B);
					END IF;
				END CASE;
			END PROCESS;
			
			Y <= RESULT(3 DOWNTO 0);
			C_B <= RESULT(4);
					
		
end ALU_4_ARCH;

