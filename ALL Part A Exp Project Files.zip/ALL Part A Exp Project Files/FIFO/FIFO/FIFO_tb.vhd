LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;  -- instead of non-standard std_logic_arith

ENTITY FIFO_tb IS
END FIFO_tb;
 
ARCHITECTURE behavior OF FIFO_tb IS 
     
    COMPONENT FIFO
    PORT(
         CLK : IN  std_logic;
         RST : IN  std_logic;
         rd_en : IN  std_logic;
         wr_en : IN  std_logic;
         data_in : IN  std_logic_vector(7 downto 0);
         data_out : OUT  std_logic_vector(7 downto 0);
         fifo_empty : OUT  std_logic;
         fifo_full : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal CLK : std_logic := '0';
   signal RST : std_logic := '0';
   signal rd_en : std_logic := '0';
   signal wr_en : std_logic := '0';
   signal data_in : std_logic_vector(7 downto 0) := (others => '0');

 	--Outputs
   signal data_out : std_logic_vector(7 downto 0);
   signal fifo_empty : std_logic;
   signal fifo_full : std_logic;

   -- Clock period definitions
   constant CLK_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: FIFO PORT MAP (
          CLK => CLK,
          RST => RST,
          rd_en => rd_en,
          wr_en => wr_en,
          data_in => data_in,
          data_out => data_out,
          fifo_empty => fifo_empty,
          fifo_full => fifo_full
        );

   -- Clock process definitions
   CLK_process :process
   begin
		CLK <= '0';
		wait for CLK_period/2;
		CLK <= '1';
		wait for CLK_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- Apply reset
      RST <= '1';
      wait for CLK_period;
      RST <= '0';
      wait for CLK_period*3;

      -- Write 10 values (1-10)
      wr_en <= '1';
      rd_en <= '0';
      for i in 1 to 10 loop
         data_in <= std_logic_vector(to_unsigned(i, 8));
         wait for CLK_period;
      end loop;
      wr_en <= '0';

      -- Read 4 values
      rd_en <= '1';
      wait for CLK_period*4;
      rd_en <= '0';

      wait for CLK_period*10;

      -- Write 10 values (11-20)
      wr_en <= '1';
      for i in 11 to 20 loop
         data_in <= std_logic_vector(to_unsigned(i, 8));
         wait for CLK_period;
      end loop;
      wr_en <= '0';

      wait for CLK_period*10;

      -- Read 4 values
      rd_en <= '1';
      wait for CLK_period*4;
      rd_en <= '0';

      wait for CLK_period;

      -- Read 4 values
      rd_en <= '1';
      wait for CLK_period*8;
      rd_en <= '0';

      wait for CLK_period;

      -- Read 8 values
      rd_en <= '1';
      wait for CLK_period*4;
      rd_en <= '0';

      wait for CLK_period;

      -- Read 4 values
      rd_en <= '1';
      wait for CLK_period*4;
      rd_en <= '0';

      wait;
   end process;

END;
