library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity FIFO is
    Port ( CLK        : in  STD_LOGIC;
           RST        : in  STD_LOGIC;
           rd_en      : in  STD_LOGIC;
           wr_en      : in  STD_LOGIC;
           data_in    : in  STD_LOGIC_VECTOR (7 downto 0);
           data_out   : out STD_LOGIC_VECTOR (7 downto 0);
           fifo_empty : out STD_LOGIC;
           fifo_full  : out STD_LOGIC);
end FIFO;

architecture FIFO_arch of FIFO is

    constant depth : integer := 16;
    type memory_type is array (0 to depth-1) of std_logic_vector(7 downto 0);
    signal memory   : memory_type := (others => (others => '0'));

    signal readptr  : integer range 0 to depth-1 := 0;
    signal writeptr : integer range 0 to depth-1 := 0;
    signal count    : integer range 0 to depth   := 0;

begin

    process(CLK, RST)
    begin
        if (RST = '1') then
            memory    <= (others => (others => '0'));
            data_out  <= (others => '0');
            readptr   <= 0;
            writeptr  <= 0;
            count     <= 0;
            fifo_empty <= '1';
            fifo_full  <= '0';

        elsif rising_edge(CLK) then

            -- READ operation
            if (rd_en = '1' and count > 0) then
                data_out <= memory(readptr);
                if (readptr = depth-1) then
                    readptr <= 0;
                else
                    readptr <= readptr + 1;
                end if;
                count <= count - 1;
            end if;

            -- WRITE operation
            if (wr_en = '1' and count < depth) then
                memory(writeptr) <= data_in;
                if (writeptr = depth-1) then
                    writeptr <= 0;
                else
                    writeptr <= writeptr + 1;
                end if;
                count <= count + 1;
            end if;

            -- STATUS FLAGS
            if (count = 0) then
                fifo_empty <= '1';
            else
                fifo_empty <= '0';
            end if;

            if (count = depth) then
                fifo_full <= '1';
            else
                fifo_full <= '0';
            end if;

        end if;
    end process;

end FIFO_arch;
